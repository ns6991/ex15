package com.example.ex15;

public class Meal1 {
    public static final String MEALS_TABLE = "Meals";
    public static final String KEY_ID = "_id";
    public static final String FIRST_MEAL = "_FirstMeal";
    public static final String MAIN_MEAL = "_MainMeal";
    public static final String EXTRA = "_Extra";
    public static final String DESSERT = "_Dessert";
    public static final String DRINK = "_Drink";
}
