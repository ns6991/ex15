package com.example.ex15;

public class Order1 {
    public static final String TABLE_ORDERS = "Orders";
    public static final String KEY_ID = "_id";
    public static final String RESTAURANT_ID = "RestID";
    public static final String RESTAURANT_NAME = "RestName";
    public static final String USER_ID = "UserID";
    public static final String MEAL_ID = "MealID";
    public static final String USER_NAME = "UserName";
    public static final String DATE = "Date";
    public static final String TIME = "Time";

}
