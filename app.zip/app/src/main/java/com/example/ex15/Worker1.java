package com.example.ex15;

public class Worker1 {

    public final static String WORKERS_TABLE = "Workers";
    public final static String KEY_ID = "_id";
    public final static String FIRST_NAME = "_firstName";
    public final static String LAST_NAME = "_lastName";
    public final static String WORKER_ID = "_workerID";
    public final static String COMPANY_NAME = "_companyName";
    public final static String PHONE_NUMBER = "_phoneNumber";
    public final static String ACTIVE = "_active";

}