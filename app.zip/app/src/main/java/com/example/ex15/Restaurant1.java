package com.example.ex15;

public class Restaurant1 {
    public static final String TABLE_RESTAURANT = "Restaurant";
    public static final String KEY_ID = "_id";
    public static final String NAME="CompanyName";
    public static final String MAIN_PHONE="MainNumber";
    public static final String SECONDARY_PHONE="SecNumber";
    public static final String ACTIVE="active";

}
